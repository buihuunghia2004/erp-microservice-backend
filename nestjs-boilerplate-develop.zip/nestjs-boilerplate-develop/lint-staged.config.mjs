export default {
  '*.ts': ['pnpm lint', 'pnpm format'],
};
