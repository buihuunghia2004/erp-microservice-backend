# API Documentation

This section provides an overview of the API documentation for the project.

---

[[toc]]

## Endpoints

We use swagger to document the API endpoints. You can access the API documentation by visiting the `/api-docs` route in your browser.

For example, if your application is running on `http://localhost:3000`, you can access the API documentation at <http://localhost:3000/api-docs>.

## Authentication

## Error Handling
