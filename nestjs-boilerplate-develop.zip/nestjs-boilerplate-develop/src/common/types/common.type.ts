import { Branded } from './types';

export type Uuid = Branded<string, 'Uuid'>;
