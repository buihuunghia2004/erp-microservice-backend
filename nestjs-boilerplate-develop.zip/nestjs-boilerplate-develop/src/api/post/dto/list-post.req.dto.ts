import { PageOptionsDto } from '@/common/dto/offset-pagination/page-options.dto';

export class ListPostReqDto extends PageOptionsDto {}
