import { CreatePostReqDto } from './create-post.req.dto';

export class UpdatePostReqDto extends CreatePostReqDto {}
