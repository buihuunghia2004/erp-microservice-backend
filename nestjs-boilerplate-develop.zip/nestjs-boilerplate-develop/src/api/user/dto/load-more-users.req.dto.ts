import { PageOptionsDto } from '@/common/dto/cursor-pagination/page-options.dto';

export class LoadMoreUsersReqDto extends PageOptionsDto {}
