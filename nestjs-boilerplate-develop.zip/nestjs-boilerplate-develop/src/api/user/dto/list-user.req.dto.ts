import { PageOptionsDto } from '@/common/dto/offset-pagination/page-options.dto';

export class ListUserReqDto extends PageOptionsDto {}
